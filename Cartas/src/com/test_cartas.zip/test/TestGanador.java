package com.test;

import com.entidades.Jugadores;

public class TestGanador {

	public static void main(String[] args) {

		Jugadores jugadores = new Jugadores();
		jugadores.jugar();

	}

}
